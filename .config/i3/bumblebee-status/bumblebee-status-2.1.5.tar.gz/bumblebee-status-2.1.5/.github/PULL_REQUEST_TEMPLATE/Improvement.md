---
name: Improvement
about: You have some improvement to make bumblebee-status bar better?
---

### Improvement
<!-- Fill in the relevant information below to help triage your issue. -->

